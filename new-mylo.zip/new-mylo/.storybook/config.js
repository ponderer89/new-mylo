import React from 'react'
import { configure, addDecorator } from '@storybook/react'
import { ThemeProvider } from 'styled-components/macro'
import theme from '../src/theme'
import GlobalStyles from '../src/global-styles'

function loadStories() {
  addDecorator(s => (
    <ThemeProvider theme={theme}>
      <>
        {s()}
        <GlobalStyles />
      </>
    </ThemeProvider>
  ))
  require('../src/stories')
}

configure(loadStories, module)
