import { number, string, object, date } from 'yup'

const screen1Schema = object({})
